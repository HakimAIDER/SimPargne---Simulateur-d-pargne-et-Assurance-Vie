
import React from 'react';

const Step: React.FC<{ number: string; title: string; children: React.ReactNode }> = ({ number, title, children }) => (
    <div className="relative">
      <div className="absolute -left-4 top-1 flex items-center justify-center h-8 w-8 rounded-full bg-slate-700 text-sky-400 font-bold">
        {number}
      </div>
      <div className="pl-8">
        <h3 className="text-xl font-bold text-white">{title}</h3>
        <p className="mt-2 text-slate-400">{children}</p>
      </div>
    </div>
  );
  

const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="py-16 sm:py-20 bg-slate-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-extrabold text-white">En trois étapes simples</h2>
        </div>
        <div className="space-y-12">
            <Step number="1" title="Définissez vos paramètres">
                Indiquez votre versement initial, vos apports mensuels et la durée sur laquelle vous souhaitez investir.
            </Step>
            <Step number="2" title="Choisissez votre profil">
                Sélectionnez le profil de risque qui vous correspond (prudent, équilibré ou dynamique) pour ajuster le rendement cible.
            </Step>
            <Step number="3" title="Analysez vos résultats">
                Visualisez instantanément la projection de votre épargne, les gains potentiels et une estimation de la fiscalité applicable.
            </Step>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
