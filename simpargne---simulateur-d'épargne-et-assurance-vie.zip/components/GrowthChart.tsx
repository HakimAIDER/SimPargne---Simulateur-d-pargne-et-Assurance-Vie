
import React from 'react';
import { ResponsiveContainer, AreaChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Area } from 'recharts';
import { ChartDataPoint } from '../types';

interface GrowthChartProps {
  data: ChartDataPoint[];
}

const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800 p-4 border border-slate-600 rounded-lg shadow-xl">
          <p className="label font-bold text-white">{`Année ${label}`}</p>
          <p className="text-sky-400">{`Capital Total : ${payload[2].value.toLocaleString('fr-FR')} €`}</p>
          <p className="text-emerald-400">{`Gains : ${payload[1].value.toLocaleString('fr-FR')} €`}</p>
          <p className="text-slate-400">{`Total Versé : ${payload[0].value.toLocaleString('fr-FR')} €`}</p>
        </div>
      );
    }
    return null;
  };

const GrowthChart: React.FC<GrowthChartProps> = ({ data }) => {
  if (!data.length) {
    return null;
  }

  return (
    <div className="w-full h-96 bg-slate-800 p-4 rounded-lg shadow-lg">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{ top: 5, right: 20, left: 30, bottom: 5 }}
        >
          <defs>
            <linearGradient id="colorInvested" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#64748b" stopOpacity={0.6}/>
              <stop offset="95%" stopColor="#64748b" stopOpacity={0}/>
            </linearGradient>
            <linearGradient id="colorGains" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#34d399" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#34d399" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
          <XAxis dataKey="year" stroke="#94a3b8" />
          <YAxis 
            stroke="#94a3b8" 
            tickFormatter={(value) => `${(Number(value) / 1000).toLocaleString('fr-FR')}k`}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ color: '#cbd5e1' }} />
          <Area 
            type="monotone" 
            dataKey="totalInvested" 
            name="Total Versé"
            stackId="1" 
            stroke="#64748b" 
            fill="url(#colorInvested)"
            fillOpacity={1}
            />
          <Area 
            type="monotone" 
            dataKey="totalGains" 
            name="Gains"
            stackId="1" 
            stroke="#34d399" 
            fill="url(#colorGains)" 
            fillOpacity={1}
            />
           <Area 
            type="monotone" 
            dataKey="totalCapital" 
            name="Capital Total"
            stroke="#38bdf8" 
            fill="transparent" 
            strokeWidth={2}
            dot={true}
            activeDot={{r: 6}}
            />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default GrowthChart;
