import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative text-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <video 
          autoPlay 
          loop 
          muted 
          playsInline 
          className="w-full h-full object-cover"
          src="https://videos.openai.com/az/vg-assets/task_01k8qpjyxae758fafnyqqn3sw6%2Ftask_01k8qpjyxae758fafnyqqn3sw6_genid_1e453e13-80ac-4c3a-91de-88d1a26c5bcd_25_10_29_10_01_600455%2Fvideos%2F00000_179150579%2Fsource.mp4?se=2025-11-04T10%3A02%3A39Z&sp=r&sv=2024-08-04&sr=b&skoid=aa5ddad1-c91a-4f0a-9aca-e20682cc8969&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2025-10-29T04%3A56%3A19Z&ske=2025-11-05T05%3A01%3A19Z&sks=b&skv=2024-08-04&sig=wfYlWQnt6wAZyMFEhK7OiEJXwlc8IJuNfspTBpnn5dg%3D&ac=oaivgprodscus2"
        >
          Votre navigateur ne supporte pas la balise vidéo.
        </video>
        <div className="absolute inset-0 bg-slate-900/70" />
      </div>

       <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24 sm:pt-28 sm:pb-32">
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight">
          Anticipez votre avenir financier
        </h1>
        <p className="mt-6 text-lg text-slate-300 max-w-2xl mx-auto">
          Notre simulateur d'épargne et d'assurance vie vous aide à visualiser la croissance de votre patrimoine et à prendre des décisions éclairées.
        </p>
        <div className="mt-10 flex justify-center">
          <a
            href="#simulator"
            className="bg-sky-500 hover:bg-sky-600 text-white font-bold py-3 px-8 rounded-lg text-lg transition-transform duration-200 ease-in-out transform hover:scale-105"
          >
            Commencer la simulation
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;