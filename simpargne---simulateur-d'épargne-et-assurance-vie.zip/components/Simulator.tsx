
import React, { useState, useMemo } from 'react';
import { ChartDataPoint, RiskProfile, SimulationParams } from '../types';
import { RISK_PROFILE_CONFIG } from '../constants';
import SliderInput from './SliderInput';
import RiskProfileSelector from './RiskProfileSelector';
import GrowthChart from './GrowthChart';
import ResultsCard from './ResultsCard';

const Simulator: React.FC = () => {
  const [params, setParams] = useState<SimulationParams>({
    initialInvestment: 10000,
    monthlyContribution: 200,
    duration: 10,
    riskProfile: RiskProfile.Equilibre,
    annualReturn: RISK_PROFILE_CONFIG[RiskProfile.Equilibre].return,
  });

  const handleParamChange = (field: keyof SimulationParams, value: number | RiskProfile) => {
    setParams(prev => {
      const newParams = { ...prev, [field]: value };
      if (field === 'riskProfile') {
        newParams.annualReturn = RISK_PROFILE_CONFIG[value as RiskProfile].return;
      }
      return newParams;
    });
  };

  const simulationData = useMemo<ChartDataPoint[]>(() => {
    const data: ChartDataPoint[] = [];
    let currentCapital = params.initialInvestment;
    let totalInvested = params.initialInvestment;

    for (let year = 0; year <= params.duration; year++) {
        if (year > 0) {
            const yearlyContribution = params.monthlyContribution * 12;
            totalInvested += yearlyContribution;
            currentCapital += yearlyContribution;
            currentCapital *= (1 + params.annualReturn / 100);
        }
        
        data.push({
            year: year,
            totalInvested: Math.round(totalInvested),
            totalGains: Math.round(currentCapital - totalInvested),
            totalCapital: Math.round(currentCapital),
        });
    }
    return data;
  }, [params]);

  return (
    <section id="simulator" className="py-16 sm:py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <header className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-extrabold text-white">
            Simulateur d'Épargne
          </h2>
          <p className="mt-3 text-lg text-slate-400">
            Projetez la croissance de votre <span className="text-sky-400 font-semibold">assurance vie</span> en quelques clics.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 bg-slate-800 p-6 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold text-white mb-6 border-b border-slate-700 pb-4">Paramètres</h3>
            
            <SliderInput
              label="Versement Initial"
              value={params.initialInvestment}
              min={0}
              max={100000}
              step={1000}
              unit="€"
              onChange={(e) => handleParamChange('initialInvestment', parseInt(e.target.value, 10))}
            />

            <SliderInput
              label="Versements Mensuels"
              value={params.monthlyContribution}
              min={0}
              max={2000}
              step={50}
              unit="€"
              onChange={(e) => handleParamChange('monthlyContribution', parseInt(e.target.value, 10))}
            />

            <SliderInput
              label="Durée de l'investissement"
              value={params.duration}
              min={1}
              max={40}
              step={1}
              unit="ans"
              onChange={(e) => handleParamChange('duration', parseInt(e.target.value, 10))}
            />
            
            <RiskProfileSelector 
              selectedProfile={params.riskProfile}
              onProfileChange={(profile) => handleParamChange('riskProfile', profile)}
            />

            <SliderInput
              label="Rendement Annuel Cible"
              value={params.annualReturn}
              min={0}
              max={15}
              step={0.5}
              unit="%"
              onChange={(e) => handleParamChange('annualReturn', parseFloat(e.target.value))}
            />
          </div>

          <div className="lg:col-span-2 flex flex-col gap-8">
            <ResultsCard data={simulationData} duration={params.duration} />
            <GrowthChart data={simulationData} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Simulator;
