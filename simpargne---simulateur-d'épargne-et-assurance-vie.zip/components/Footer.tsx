
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-800 border-t border-slate-700">
      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center text-slate-500 text-sm">
        <p className="mb-2">
            Ce simulateur est un outil d'estimation à but éducatif. Les résultats ne constituent pas un conseil en investissement et ne garantissent pas les performances futures. La fiscalité peut évoluer.
        </p>
        <p>&copy; {new Date().getFullYear()} SimulÉpargne. Tous droits réservés.</p>
      </div>
    </footer>
  );
};

export default Footer;
