
import React from 'react';
import { ChartDataPoint } from '../types';
import { PFU_RATE, PFL_AFTER_8_YEARS_RATE, TAX_ALLOWANCE_SINGLE } from '../constants';
import InfoIcon from './InfoIcon';

interface ResultsCardProps {
  data: ChartDataPoint[];
  duration: number;
}

const ResultsCard: React.FC<ResultsCardProps> = ({ data, duration }) => {
  if (!data.length) {
    return null;
  }

  const finalData = data[data.length - 1];
  const { totalCapital, totalGains, totalInvested } = finalData;

  const taxRate = duration < 8 ? PFU_RATE : PFL_AFTER_8_YEARS_RATE;
  const taxableGains = duration < 8 ? totalGains : Math.max(0, totalGains - TAX_ALLOWANCE_SINGLE);
  const taxAmount = taxableGains * taxRate;
  const netCapital = totalCapital - taxAmount;
  
  const taxTooltip = `La fiscalité de l'assurance vie dépend de l'âge du contrat.
    - Avant 8 ans: Les gains sont soumis au PFU de 30%.
    - Après 8 ans: Les gains bénéficient d'un abattement annuel (4600€ pour un célibataire). Au-delà, le taux est de 7.5% (+17.2% de prélèvements sociaux).
    Simulation basée sur un rachat total pour une personne seule.`;

  const StatItem: React.FC<{ label: string; value: number; color: string }> = ({ label, value, color }) => (
    <div className="flex flex-col p-4 bg-slate-800/50 rounded-lg">
      <span className="text-sm text-slate-400">{label}</span>
      <span className={`text-2xl font-bold ${color}`}>
        {value.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
      </span>
    </div>
  );

  return (
    <div className="w-full bg-slate-800 p-6 rounded-lg shadow-lg">
      <h3 className="text-2xl font-bold text-white mb-6">Résultats de la Simulation</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatItem label="Capital Final Projeté" value={totalCapital} color="text-sky-400" />
        <StatItem label="Total des Versements" value={totalInvested} color="text-slate-300" />
        <StatItem label="Gains (Plus-Values)" value={totalGains} color="text-emerald-400" />
        <StatItem label="Montant de l'impôt" value={taxAmount} color="text-amber-400" />
      </div>

      <div className="mt-6 p-6 bg-gradient-to-r from-sky-500 to-emerald-500 rounded-lg text-center">
        <div className="flex items-center justify-center">
            <h4 className="text-lg font-semibold text-white">Capital Net après impôt</h4>
            <InfoIcon tooltip={taxTooltip} />
        </div>
        <p className="text-4xl font-extrabold text-white mt-1">
          {netCapital.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })} €
        </p>
      </div>
    </div>
  );
};

export default ResultsCard;
