
import React from 'react';
import { RiskProfile } from '../types';
import { RISK_PROFILE_CONFIG } from '../constants';

interface RiskProfileSelectorProps {
  selectedProfile: RiskProfile;
  onProfileChange: (profile: RiskProfile) => void;
}

const RiskProfileSelector: React.FC<RiskProfileSelectorProps> = ({ selectedProfile, onProfileChange }) => {
  return (
    <div className="w-full mb-6">
      <h3 className="text-slate-300 font-medium mb-3">Profil de risque</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {Object.values(RiskProfile).map((profile) => {
          const config = RISK_PROFILE_CONFIG[profile];
          const isSelected = selectedProfile === profile;
          return (
            <button
              key={profile}
              onClick={() => onProfileChange(profile)}
              className={`p-4 rounded-lg text-left transition-all duration-200 border-2 ${
                isSelected
                  ? 'border-sky-400 bg-slate-700/50 scale-105'
                  : 'border-slate-600 bg-slate-800 hover:bg-slate-700/50'
              }`}
            >
              <div className="flex items-center mb-1">
                <span className={`w-3 h-3 rounded-full ${config.color} mr-2`}></span>
                <span className="font-bold text-white">{profile}</span>
              </div>
              <p className="text-sm text-slate-400">{config.description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default RiskProfileSelector;
